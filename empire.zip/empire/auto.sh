while [[ true ]]; do
  ./run.sh
  sleep 2
done
